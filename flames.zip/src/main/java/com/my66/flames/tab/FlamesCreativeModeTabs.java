package com.my66.flames.tab;

import com.my66.flames.block.Pebble_Block;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Items;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import static com.my66.flames.FlamesMod.MODID;

public class FlamesCreativeModeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final RegistryObject<CreativeModeTab> FLAMES_TAB = CREATIVE_MODE_TABS.register("flames_tab", () -> CreativeModeTab.builder()
            .withTabsBefore(CreativeModeTabs.COMBAT)
            .icon(Items.FLINT_AND_STEEL::getDefaultInstance)
            .title(Component.translatable("creativetab.flames.flames_tab"))
            .displayItems((parameters, output) -> {
                output.accept(Pebble_Block.pebble_blockitem.get());
            }).build());

    public static void register(IEventBus eventBus) {
        CREATIVE_MODE_TABS.register(eventBus);
    }
}
