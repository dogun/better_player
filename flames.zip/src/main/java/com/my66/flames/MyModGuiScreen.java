package com.my66.flames;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;


public class MyModGuiScreen extends Screen {
    private static final ResourceLocation BG_TEXTURE =
            ResourceLocation.fromNamespaceAndPath("minecraft", "textures/gui/light_dirt_background.png");


    private EditBox firstNameBox;
    private EditBox lastNameBox;
    private boolean isMale = true;
    private boolean isEast = true;
    private int age = 18;

    private Slider ageSlider;
    private Button maleButton;
    private Button femaleButton;
    private Button eastButton;
    private Button westButton;

    private Button saveButton;
    private Button loadButton;


    public MyModGuiScreen() {
        super(Component.literal(""));
    }

    @Override
    protected void init() {
        // 姓名输入框
        this.firstNameBox = new EditBox(this.font, 30, 110, 60, 20, Component.literal("名"));
        this.firstNameBox.setMaxLength(20);
        this.addRenderableWidget(this.firstNameBox);
        this.lastNameBox = new EditBox(this.font, 30, 130, 60, 20, Component.literal("姓"));
        this.lastNameBox.setMaxLength(20);
        this.addRenderableWidget(this.lastNameBox);

        // 性别按钮
        this.maleButton = Button.builder(Component.literal("♂"), btn -> setGender(true))
                .pos(10, 30)
                .size(40, 20)
                .build();
        this.femaleButton = Button.builder(Component.literal("♀"), btn -> setGender(false))
                .pos(60, 30)
                .size(40, 20)
                .build();
        //文化按钮
        this.eastButton = Button.builder(Component.literal("东方"), btn -> setCulture(true))
                .pos(10, 90)
                .size(40, 20)
                .build();
        this.westButton = Button.builder(Component.literal("西方"), btn -> setCulture(false))
                .pos(60, 90)
                .size(40, 20)
                .build();

        //保存和加载
        this.saveButton = Button.builder(Component.literal("保存"), btn -> onSubmit())
                .pos(10, 150)
                .size(40, 20)
                .build();
        this.loadButton = Button.builder(Component.literal("加载"), btn -> onSubmit())
                .pos(60, 150)
                .size(40, 20)
                .build();

        this.addRenderableWidget(maleButton);
        this.addRenderableWidget(femaleButton);
        this.addRenderableWidget(eastButton);
        this.addRenderableWidget(westButton);
        this.addRenderableWidget(saveButton);
        this.addRenderableWidget(loadButton);
        updateGenderButtons();
        updateCultureButtons();

        // 年龄滑动条
        this.ageSlider = new Slider(80, 20, 120, 20, 1, 99, age);
        this.addRenderableWidget(this.ageSlider);
    }

    private void setGender(boolean male) {
        this.isMale = male;
        updateGenderButtons();
    }

    private void setCulture(boolean east) {
        this.isEast = east;
        updateCultureButtons();
    }


    private void updateGenderButtons() {
        this.maleButton.active = !isMale;
        this.femaleButton.active = isMale;
    }

    private void updateCultureButtons() {
        this.eastButton.active = !isEast;
        this.westButton.active = isEast;
    }

    private void onSubmit() {
        String name = firstNameBox.getValue();
        int selectedAge = ageSlider.getAge();
        String gender = isMale ? "M" : "F";
        // 你可以在此处处理提交后的逻辑，例如发送到服务端或保存
        this.minecraft.player.sendSystemMessage(Component.literal(
                "姓名: " + name + " 性别: " + gender + " 年龄: " + selectedAge
        ));
        this.onClose();
    }

    @Override
    public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTicks) {
        RenderSystem.setShaderTexture(0, BG_TEXTURE);
        int tileSize = 16;
        for (int x = 0; x < this.width; x += tileSize) {
            for (int y = 0; y < this.height; y += tileSize) {
                // 贴图区域不能超出屏幕
                int w = Math.min(tileSize, this.width - x);
                int h = Math.min(tileSize, this.height - y);
                gg.blit(BG_TEXTURE, x, y, 0, 0, w, h, tileSize, tileSize);
            }
        }
        gg.drawString(this.font, "姓：", 10, 130, 0xFFFFFF);
        gg.drawString(this.font, "名：", 10, 110, 0xFFFFFF);
        gg.drawString(this.font, "性别", 10, 10, 0xFFFFFF);
        gg.drawString(this.font, "文化：", 10, 70, 0xFFFFFF);
        gg.drawString(this.font, "年龄：", 80, 30, 0xFFFFFF);
        super.render(gg, mouseX, mouseY, partialTicks);
    }

    // 年龄滑动条内部类
    private static class Slider extends AbstractSliderButton {
        private final int min, max;

        public Slider(int x, int y, int width, int height, int min, int max, int value) {
            super(x, y, width, height, Component.literal(value + ""), (value - min) / (double)(max - min));
            this.min = min;
            this.max = max;
            this.updateMessage();
        }

        @Override
        protected void updateMessage() {
            this.setMessage(Component.literal(Integer.toString(getAge())));
        }

        @Override
        protected void applyValue() {
            this.updateMessage();
        }

        public int getAge() {
            return (int)Math.round(this.value * (max - min) + min);
        }
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        return super.mouseClicked(x, y, button) || this.firstNameBox.mouseClicked(x, y, button) || this.lastNameBox.mouseClicked(x, y, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.firstNameBox.keyPressed(keyCode, scanCode, modifiers) || this.firstNameBox.canConsumeInput() || this.lastNameBox.canConsumeInput()) {
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}