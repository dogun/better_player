package com.my66.flames;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.client.Minecraft;

@Mod.EventBusSubscriber(modid = "flames", value = Dist.CLIENT)
public class AutoOpenGuiClientEvents {
    @SubscribeEvent
    public static void onPlayerLoggedIn(ClientPlayerNetworkEvent.LoggingIn event) {
        // 需要在合适的 tick 阶段打开，否则可能有空指针
        Minecraft.getInstance().tell(() -> {
            Minecraft.getInstance().setScreen(new MyModGuiScreen());
        });
    }
}