package com.my66.flames.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class Pebble_BlockEntity extends BlockEntity {
    public Pebble_BlockEntity(BlockPos pPes, BlockState pBlockState) {
        super(Pebble_Block.PABBLE_BLOCK_ENTITY.get(), pPes, pBlockState);
    }
}
