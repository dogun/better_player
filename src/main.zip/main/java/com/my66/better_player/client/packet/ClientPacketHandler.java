package com.my66.better_player.client.packet;

import com.my66.better_player.BetterPlayer;
import com.my66.better_player.BetterPlayerMod;
import com.my66.better_player.client.gui.PlayerConfigurationGui;
import com.my66.better_player.packet.*;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ClientPacketHandler {
    public static void register() {
        ModPacketHandler.INSTANCE.registerMessage(
                ModPacketHandler.index++, ResponseDataPacket.class,
                ResponseDataPacket::encode,
                ResponseDataPacket::decode,
                (pkt, ctx) -> {
                    if ("".equals(pkt.data)) { //需要捏人
                        ctx.get().enqueueWork(() -> {
                            Minecraft.getInstance().setScreen(new PlayerConfigurationGui());
                        });
                    }else { //加载数据
                        BetterPlayer bp = BetterPlayer.getBetterPlayer(Minecraft.getInstance().player);
                        bp.setData(pkt.data);
                        BetterPlayerMod.setPlayerDataToServer(Minecraft.getInstance().player, bp);
                    }
                    ctx.get().setPacketHandled(true);
                }
        );
        ModPacketHandler.INSTANCE.registerMessage(
                ModPacketHandler.index++, RespawnResponseDataPacket.class,
                RespawnResponseDataPacket::encode,
                RespawnResponseDataPacket::decode,
                (pkt, ctx) -> {
                    ctx.get().enqueueWork(() -> {
                        String data = pkt.data;
                        PlayerConfigurationGui gui = new PlayerConfigurationGui();
                        Minecraft.getInstance().setScreen(gui);
                        gui.renderData(data, 1);
                        Minecraft.getInstance().setScreen(gui);
                        gui.renderData(data, 2);
                    });
                    ctx.get().setPacketHandled(true);
                }
        );
    }
}
