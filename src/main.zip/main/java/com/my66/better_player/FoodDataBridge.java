package com.my66.better_player;

public interface FoodDataBridge {
    void setUuid(String uuid);
    String getUuid();
}