package com.my66.better_player.packet;

import com.my66.better_player.BetterPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SetFoodLevelPacket {
    private final int foodLevel;

    public SetFoodLevelPacket(int foodLevel) { this.foodLevel = foodLevel; }
    // 编解码略...

    public static void handle(SetFoodLevelPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                BetterPlayer.getBetterPlayer(player).setEndurance(pkt.foodLevel);
                player.getFoodData().setFoodLevel(pkt.foodLevel);
                System.out.println("set food packet, set food data: " + pkt.foodLevel);
            }
        });
        ctx.get().setPacketHandled(true);
    }

    public static void encode(SetFoodLevelPacket pkt, FriendlyByteBuf buf) {
        buf.writeInt(pkt.foodLevel);
    }

    public static SetFoodLevelPacket decode(FriendlyByteBuf buf) {
        return new SetFoodLevelPacket(buf.readInt());
    }
}
