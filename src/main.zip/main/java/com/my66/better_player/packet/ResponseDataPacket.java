package com.my66.better_player.packet;

import net.minecraft.network.FriendlyByteBuf;

import java.io.UnsupportedEncodingException;

public class ResponseDataPacket {
    public final String data;
    public ResponseDataPacket(String data) { this.data = data; }

    public static void encode(ResponseDataPacket pkt, FriendlyByteBuf buf) {
        try {
            buf.writeByteArray(pkt.data.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }

    public static ResponseDataPacket decode(FriendlyByteBuf buf) {
        try {
            return new ResponseDataPacket(new String(buf.readByteArray(128), "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
    }
}
