package com.my66.better_player.packet;

import com.my66.better_player.BetterPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SetAirPacket {
    private final int air;
    public SetAirPacket(int air) { this.air = air; }

    public static void handle(SetAirPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                BetterPlayer.getBetterPlayer(player).setAirSupply(pkt.air);
                player.setAirSupply(pkt.air);
                System.out.println("set air packet, set air supply: " + pkt.air);
            }
        });
        ctx.get().setPacketHandled(true);
    }

    public static void encode(SetAirPacket pkt, FriendlyByteBuf buf) {
        buf.writeInt(pkt.air);
    }

    public static SetAirPacket decode(FriendlyByteBuf buf) {
        return new SetAirPacket(buf.readInt());
    }
}
