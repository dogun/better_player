package com.my66.better_player.packet;

import com.my66.better_player.BetterPlayer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SetHealthPacket {
    private final float health;
    public SetHealthPacket(float health) { this.health = health; }

    public static void handle(SetHealthPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player != null) {
                BetterPlayer.getBetterPlayer(player).setConstitution((int)pkt.health);
                //设置玩家的血槽
                AttributeInstance maxHealth = player.getAttribute(Attributes.MAX_HEALTH);
                if (maxHealth != null) {
                    maxHealth.setBaseValue(pkt.health);
                    System.out.println("set health packet, set max health: " + pkt.health);
                }

                //设置玩家的血量
                player.level().getServer().execute(
                        () -> {
                            player.setHealth(pkt.health);
                            System.out.println("set health packet, set health: " + pkt.health);
                        }
                );
            }
        });
        ctx.get().setPacketHandled(true);
    }

    public static void encode(SetHealthPacket pkt, FriendlyByteBuf buf) {
        buf.writeFloat(pkt.health);
    }

    public static SetHealthPacket decode(FriendlyByteBuf buf) {
        return new SetHealthPacket(buf.readFloat());
    }
}
