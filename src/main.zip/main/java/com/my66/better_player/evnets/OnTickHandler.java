package com.my66.better_player.evnets;

import com.my66.better_player.BetterPlayer;
import com.my66.better_player.BetterPlayerMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "better_player")
public class OnTickHandler {

    // 设置检查周期（120天*24000tick/天）
    private static final long ADJUST_INTERVAL = 1L * 240;

    @SubscribeEvent
    public static void onWorldTick(TickEvent.LevelTickEvent event) {
        // 只在服务端主世界执行
        if (event.level instanceof ServerLevel serverLevel && !event.level.isClientSide
                && event.phase == TickEvent.Phase.END) {

            // 每120天执行一次
            if (serverLevel.getDayTime() % ADJUST_INTERVAL == 0) {
                for (ServerPlayer player : serverLevel.getPlayers(serverPlayer -> true)) {
                    System.out.println("player: " + player.getScoreboardName() + " update: " + serverLevel.getDayTime());
                    //年龄加1
                    String data = BetterPlayerMod.loadSSData(player);
                    BetterPlayer bp = BetterPlayer.getBetterPlayer(player);
                    bp.setData(data);
                    bp.setAge(bp.getAge() + 1);
                    BetterPlayerMod.setPlayerDataLocal(player, bp);
                    BetterPlayerMod.saveSSData(player, bp.getData());
                }
            }
        }
    }
}